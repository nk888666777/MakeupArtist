List of sites comprised in the product:
	+ Home Site
	+ Artist Site (Products)
	+ Artist Site (Detailed Information)
	+ Booking Site
	+ About Us Site
	+ Contact Us Site
	+ FAQs Site
*Product is currently 85% completed.